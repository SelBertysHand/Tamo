# Тамо: облачная сборка IPA

1. Создайте на github.com новый репозиторий (Private подойдёт).
2. Загрузите в него все файлы из этого архива (Add file → Upload files).
   Если папка .github не загрузилась: Add file → Create new file, имя
   `.github/workflows/build.yml`, вставьте содержимое из архива.
3. Вкладка Actions → Build IPA → Run workflow. Сборка идёт 5–10 минут.
4. Откройте завершённый запуск, внизу в Artifacts скачайте Tamo-ipa (zip с Tamo.ipa).
5. Установите через Sideloadly (sideloadly.io) со своим Apple ID. Подпись живёт 7 дней.
